import discord
import os

# Bot configuration
BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "your_bot_token_here")
COMMAND_PREFIX = "!"

# Bot intents - reduced for compatibility
INTENTS = discord.Intents.default()
# INTENTS.message_content = True  # Requires privileged intent
# INTENTS.members = True          # Requires privileged intent
INTENTS.guilds = True

# Colors for embeds
COLORS = {
    'success': 0x00ff00,
    'error': 0xff0000,
    'warning': 0xffff00,
    'info': 0x0099ff,
    'novarix': 0x7c3aed  # Purple color for branding
}

# Ticket configuration
TICKET_CATEGORY_NAME = "Support Tickets"
TICKET_LOG_CHANNEL = "ticket-logs"

# Security configuration
MUTE_ROLE_NAME = "Muted"
MAX_WARNINGS = 3

# Bot branding
FOOTER_TEXT = "Powered by Novarix Studio"
