import discord
from discord.ext import commands
from discord import app_commands
import json
import datetime
from config import COLORS, FOOTER_TEXT, MUTE_ROLE_NAME, MAX_WARNINGS

class Security(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    def load_warnings(self):
        """Load warnings from JSON file"""
        try:
            with open('data/warnings.json', 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def save_warnings(self, warnings):
        """Save warnings to JSON file"""
        with open('data/warnings.json', 'w') as f:
            json.dump(warnings, f, indent=2)
    
    def load_muted_users(self):
        """Load muted users from JSON file"""
        try:
            with open('data/muted_users.json', 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def save_muted_users(self, muted_users):
        """Save muted users to JSON file"""
        with open('data/muted_users.json', 'w') as f:
            json.dump(muted_users, f, indent=2)
    
    async def get_or_create_mute_role(self, guild):
        """Get or create mute role"""
        mute_role = discord.utils.get(guild.roles, name=MUTE_ROLE_NAME)
        
        if not mute_role:
            mute_role = await guild.create_role(
                name=MUTE_ROLE_NAME,
                permissions=discord.Permissions(send_messages=False, speak=False),
                reason="Mute role for moderation"
            )
            
            # Set permissions for all channels
            for channel in guild.channels:
                await channel.set_permissions(mute_role, send_messages=False, speak=False)
        
        return mute_role
    
    @app_commands.command(name="kick", description="Kick a member from the server")
    @app_commands.describe(member="The member to kick", reason="Reason for kicking")
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Kick a member from the server"""
        if not interaction.user.guild_permissions.kick_members:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to kick members.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You cannot kick someone with a higher or equal role.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            await member.kick(reason=reason)
            embed = discord.Embed(
                title="👢 Member Kicked",
                description=f"{member.mention} has been kicked.\n**Reason:** {reason}",
                color=COLORS['warning']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Error",
                description="I don't have permission to kick this member.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.describe(member="The member to ban", reason="Reason for banning", delete_days="Days of messages to delete (0-7)")
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided", delete_days: int = 0):
        """Ban a member from the server"""
        if not interaction.user.guild_permissions.ban_members:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to ban members.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You cannot ban someone with a higher or equal role.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if delete_days < 0 or delete_days > 7:
            delete_days = 0
        
        try:
            await member.ban(reason=reason, delete_message_days=delete_days)
            embed = discord.Embed(
                title="🔨 Member Banned",
                description=f"{member.mention} has been banned.\n**Reason:** {reason}",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Error",
                description="I don't have permission to ban this member.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="mute", description="Mute a member")
    @app_commands.describe(member="The member to mute", reason="Reason for muting")
    async def mute(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Mute a member"""
        if not interaction.user.guild_permissions.manage_roles:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to manage roles.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        mute_role = await self.get_or_create_mute_role(interaction.guild)
        
        if mute_role in member.roles:
            embed = discord.Embed(
                title="❌ Already Muted",
                description="This member is already muted.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            await member.add_roles(mute_role, reason=reason)
            
            # Save muted user data
            muted_users = self.load_muted_users()
            muted_users[str(member.id)] = {
                'guild_id': interaction.guild.id,
                'muted_at': datetime.datetime.now().isoformat(),
                'reason': reason,
                'muted_by': interaction.user.id
            }
            self.save_muted_users(muted_users)
            
            embed = discord.Embed(
                title="🔇 Member Muted",
                description=f"{member.mention} has been muted.\n**Reason:** {reason}",
                color=COLORS['warning']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Error",
                description="I don't have permission to mute this member.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="unmute", description="Unmute a member")
    @app_commands.describe(member="The member to unmute")
    async def unmute(self, interaction: discord.Interaction, member: discord.Member):
        """Unmute a member"""
        if not interaction.user.guild_permissions.manage_roles:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to manage roles.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        mute_role = discord.utils.get(interaction.guild.roles, name=MUTE_ROLE_NAME)
        
        if not mute_role or mute_role not in member.roles:
            embed = discord.Embed(
                title="❌ Not Muted",
                description="This member is not muted.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            await member.remove_roles(mute_role, reason="Unmuted by moderator")
            
            # Remove from muted users data
            muted_users = self.load_muted_users()
            if str(member.id) in muted_users:
                del muted_users[str(member.id)]
                self.save_muted_users(muted_users)
            
            embed = discord.Embed(
                title="🔊 Member Unmuted",
                description=f"{member.mention} has been unmuted.",
                color=COLORS['success']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Error",
                description="I don't have permission to unmute this member.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="warn", description="Warn a member")
    @app_commands.describe(member="The member to warn", reason="Reason for warning")
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Warn a member"""
        if not interaction.user.guild_permissions.manage_messages:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to warn members.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        warnings = self.load_warnings()
        guild_id = str(interaction.guild.id)
        user_id = str(member.id)
        
        if guild_id not in warnings:
            warnings[guild_id] = {}
        
        if user_id not in warnings[guild_id]:
            warnings[guild_id][user_id] = []
        
        warning_data = {
            'reason': reason,
            'warned_by': interaction.user.id,
            'warned_at': datetime.datetime.now().isoformat()
        }
        
        warnings[guild_id][user_id].append(warning_data)
        self.save_warnings(warnings)
        
        warning_count = len(warnings[guild_id][user_id])
        
        embed = discord.Embed(
            title="⚠️ Member Warned",
            description=f"{member.mention} has been warned.\n**Reason:** {reason}\n**Warning Count:** {warning_count}/{MAX_WARNINGS}",
            color=COLORS['warning']
        )
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
        
        # Auto-actions based on warning count
        if warning_count >= MAX_WARNINGS:
            try:
                mute_role = await self.get_or_create_mute_role(interaction.guild)
                await member.add_roles(mute_role, reason=f"Auto-mute: {MAX_WARNINGS} warnings reached")
                
                embed = discord.Embed(
                    title="🔇 Auto-Mute",
                    description=f"{member.mention} has been automatically muted for reaching {MAX_WARNINGS} warnings.",
                    color=COLORS['error']
                )
                embed.set_footer(text=FOOTER_TEXT)
                await interaction.followup.send(embed=embed)
            except discord.Forbidden:
                pass
    
    @app_commands.command(name="warnings", description="View warnings for a member")
    @app_commands.describe(member="The member to check warnings for")
    async def warnings(self, interaction: discord.Interaction, member: discord.Member):
        """View warnings for a member"""
        warnings = self.load_warnings()
        guild_id = str(interaction.guild.id)
        user_id = str(member.id)
        
        if guild_id not in warnings or user_id not in warnings[guild_id]:
            embed = discord.Embed(
                title="✅ No Warnings",
                description=f"{member.mention} has no warnings.",
                color=COLORS['success']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
            return
        
        user_warnings = warnings[guild_id][user_id]
        
        embed = discord.Embed(
            title=f"⚠️ Warnings for {member.display_name}",
            description=f"Total warnings: {len(user_warnings)}",
            color=COLORS['warning']
        )
        
        for i, warning in enumerate(user_warnings[-5:], 1):  # Show last 5 warnings
            warned_by = self.bot.get_user(warning['warned_by'])
            warned_by_name = warned_by.name if warned_by else "Unknown"
            embed.add_field(
                name=f"Warning {i}",
                value=f"**Reason:** {warning['reason']}\n**By:** {warned_by_name}\n**Date:** {warning['warned_at'][:10]}",
                inline=False
            )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="clear", description="Clear messages from a channel")
    @app_commands.describe(amount="Number of messages to delete (1-100)")
    async def clear(self, interaction: discord.Interaction, amount: int):
        """Clear messages from a channel"""
        if not interaction.user.guild_permissions.manage_messages:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to manage messages.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if amount < 1 or amount > 100:
            embed = discord.Embed(
                title="❌ Invalid Amount",
                description="Please specify a number between 1 and 100.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            deleted = await interaction.channel.purge(limit=amount)
            embed = discord.Embed(
                title="🗑️ Messages Cleared",
                description=f"Deleted {len(deleted)} message(s).",
                color=COLORS['success']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, delete_after=5)
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Error",
                description="I don't have permission to delete messages in this channel.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Security(bot))
