import discord
from discord.ext import commands
from discord import app_commands
from config import COLORS, FOOTER_TEXT

class HelpView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
    
    @discord.ui.select(
        placeholder="Choose a category...",
        options=[
            discord.SelectOption(label="🔒 Security", description="Moderation and security commands", value="security"),
            discord.SelectOption(label="🎫 Tickets", description="Support ticket system", value="tickets"),
            discord.SelectOption(label="🛠️ Utility", description="Server and user information", value="utility"),
            discord.SelectOption(label="🎮 Fun", description="Entertainment and games", value="fun"),
            discord.SelectOption(label="📚 All Commands", description="View all available commands", value="all")
        ]
    )
    async def select_category(self, interaction: discord.Interaction, select: discord.ui.Select):
        """Handle category selection"""
        category = select.values[0]
        
        if category == "security":
            embed = self.get_security_help()
        elif category == "tickets":
            embed = self.get_tickets_help()
        elif category == "utility":
            embed = self.get_utility_help()
        elif category == "fun":
            embed = self.get_fun_help()
        elif category == "all":
            embed = self.get_all_commands_help()
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    def get_security_help(self):
        """Get security commands help"""
        embed = discord.Embed(
            title="🔒 Security Commands",
            description="Moderation and security features to keep your server safe.",
            color=COLORS['error']
        )
        
        commands = [
            ("**/kick**", "Kick a member from the server"),
            ("**/ban**", "Ban a member from the server"),
            ("**/mute**", "Mute a member (prevents them from talking)"),
            ("**/unmute**", "Remove mute from a member"),
            ("**/warn**", "Issue a warning to a member"),
            ("**/warnings**", "View warnings for a member"),
            ("**/clear**", "Delete multiple messages at once")
        ]
        
        for cmd, desc in commands:
            embed.add_field(name=cmd, value=desc, inline=False)
        
        embed.add_field(
            name="🔐 Required Permissions",
            value="Most security commands require **Manage Messages**, **Kick Members**, **Ban Members**, or **Manage Roles** permissions.",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        return embed
    
    def get_tickets_help(self):
        """Get tickets commands help"""
        embed = discord.Embed(
            title="🎫 Ticket System",
            description="Support ticket system for user assistance.",
            color=COLORS['info']
        )
        
        commands = [
            ("**/ticket-setup**", "Set up the ticket system in a channel"),
            ("**/ticket-info**", "Get information about a specific ticket"),
            ("**/ticket-stats**", "View ticket statistics for the server")
        ]
        
        for cmd, desc in commands:
            embed.add_field(name=cmd, value=desc, inline=False)
        
        embed.add_field(
            name="📋 How Tickets Work",
            value="1. Use `/ticket-setup` to create a ticket panel\n2. Users click the button to create tickets\n3. Private channels are created for support\n4. Staff can help users in these channels\n5. Tickets can be closed when resolved",
            inline=False
        )
        
        embed.add_field(
            name="🔐 Required Permissions",
            value="Setting up tickets requires **Manage Channels** permission.",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        return embed
    
    def get_utility_help(self):
        """Get utility commands help"""
        embed = discord.Embed(
            title="🛠️ Utility Commands",
            description="Useful information and server management tools.",
            color=COLORS['success']
        )
        
        commands = [
            ("**/ping**", "Check the bot's response time"),
            ("**/serverinfo**", "Get detailed information about the server"),
            ("**/userinfo**", "Get information about a user"),
            ("**/avatar**", "Display a user's avatar"),
            ("**/botinfo**", "Get information about the bot"),
            ("**/roleinfo**", "Get information about a role")
        ]
        
        for cmd, desc in commands:
            embed.add_field(name=cmd, value=desc, inline=False)
        
        embed.add_field(
            name="💡 Tips",
            value="• Most utility commands can be used by anyone\n• Use these to get quick information about users, roles, and the server\n• Perfect for moderators and curious members alike",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        return embed
    
    def get_fun_help(self):
        """Get fun commands help"""
        embed = discord.Embed(
            title="🎮 Fun Commands",
            description="Entertainment features to keep your server lively.",
            color=COLORS['warning']
        )
        
        commands = [
            ("**/8ball**", "Ask the magic 8-ball a question"),
            ("**/roll**", "Roll a dice with customizable sides"),
            ("**/coinflip**", "Flip a coin (heads or tails)"),
            ("**/choose**", "Pick randomly from a list of options"),
            ("**/joke**", "Get a random joke"),
            ("**/compliment**", "Give someone a compliment"),
            ("**/meme**", "Get a random meme quote"),
            ("**/rps**", "Play Rock Paper Scissors with the bot"),
            ("**/quote**", "Get an inspirational quote")
        ]
        
        for cmd, desc in commands:
            embed.add_field(name=cmd, value=desc, inline=False)
        
        embed.add_field(
            name="🎉 Perfect For",
            value="• Breaking the ice in conversations\n• Server events and games\n• Keeping members entertained\n• Adding some humor to your day",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        return embed
    
    def get_all_commands_help(self):
        """Get all commands overview"""
        embed = discord.Embed(
            title="📚 All Commands Overview",
            description="Complete list of all available bot features.",
            color=COLORS['novarix']
        )
        
        categories = [
            ("🔒 **Security (7 commands)**", "kick, ban, mute, unmute, warn, warnings, clear"),
            ("🎫 **Tickets (3 commands)**", "ticket-setup, ticket-info, ticket-stats"),
            ("🛠️ **Utility (6 commands)**", "ping, serverinfo, userinfo, avatar, botinfo, roleinfo"),
            ("🎮 **Fun (9 commands)**", "8ball, roll, coinflip, choose, joke, compliment, meme, rps, quote")
        ]
        
        for category, commands in categories:
            embed.add_field(name=category, value=commands, inline=False)
        
        embed.add_field(
            name="📖 Getting Help",
            value="• Use this dropdown menu to explore specific categories\n• Each command has detailed descriptions and usage examples\n• Commands use Discord's new slash command system",
            inline=False
        )
        
        embed.add_field(
            name="🔧 Setup Requirements",
            value="• Most commands work immediately\n• Security commands need appropriate permissions\n• Ticket system requires initial setup with `/ticket-setup`",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        return embed

class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="help", description="Get help with bot commands and features")
    async def help(self, interaction: discord.Interaction):
        """Main help command"""
        embed = discord.Embed(
            title="🤖 Novarix Studio Bot Help",
            description="Welcome to the comprehensive Discord bot! Select a category below to learn more about available commands.",
            color=COLORS['novarix']
        )
        
        embed.add_field(
            name="🔒 Security System",
            value="Advanced moderation tools including kick, ban, mute, warn, and message management.",
            inline=True
        )
        
        embed.add_field(
            name="🎫 Ticket System",
            value="Professional support ticket system for user assistance and issue resolution.",
            inline=True
        )
        
        embed.add_field(
            name="🛠️ Utility Tools",
            value="Information commands for users, servers, roles, and bot statistics.",
            inline=True
        )
        
        embed.add_field(
            name="🎮 Fun Features",
            value="Entertainment commands including games, jokes, and interactive activities.",
            inline=True
        )
        
        embed.add_field(
            name="⚡ Quick Start",
            value="• All commands use `/` (slash commands)\n• Type `/` and see suggestions\n• Most features work immediately\n• Some require specific permissions",
            inline=False
        )
        
        embed.add_field(
            name="🆘 Need More Help?",
            value="Use the dropdown menu below to explore specific command categories with detailed explanations and examples.",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        
        view = HelpView()
        await interaction.response.send_message(embed=embed, view=view)
    
    @app_commands.command(name="about", description="Learn about Novarix Studio Bot")
    async def about(self, interaction: discord.Interaction):
        """About the bot"""
        embed = discord.Embed(
            title="🌟 About Novarix Studio Bot",
            description="A comprehensive Discord bot designed to enhance your server experience with powerful moderation, support, and entertainment features.",
            color=COLORS['novarix']
        )
        
        embed.add_field(
            name="🎯 Our Mission",
            value="To provide server administrators and communities with professional-grade tools that are easy to use and highly effective.",
            inline=False
        )
        
        embed.add_field(
            name="✨ Key Features",
            value="• **Advanced Security**: Comprehensive moderation system\n• **Smart Tickets**: Professional support system\n• **Rich Utilities**: Detailed server and user information\n• **Fun Activities**: Games and entertainment for your community",
            inline=False
        )
        
        embed.add_field(
            name="🛡️ Security First",
            value="Built with security in mind, featuring proper permission checks, audit logging, and safe command execution.",
            inline=False
        )
        
        embed.add_field(
            name="🚀 Modern Technology",
            value="• Discord.py with slash commands\n• Real-time data processing\n• Persistent data storage\n• Efficient performance optimization",
            inline=False
        )
        
        embed.add_field(
            name="🎨 Novarix Studio",
            value="Crafted with passion by the Novarix Studio team, dedicated to creating exceptional Discord experiences.",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Help(bot))
