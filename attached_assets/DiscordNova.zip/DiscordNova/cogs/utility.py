import discord
from discord.ext import commands
from discord import app_commands
import datetime
import platform
from config import COLORS, FOOTER_TEXT

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="ping", description="Check the bot's latency")
    async def ping(self, interaction: discord.Interaction):
        """Check bot latency"""
        latency = round(self.bot.latency * 1000)
        
        if latency < 100:
            color = COLORS['success']
            status = "Excellent"
        elif latency < 200:
            color = COLORS['warning']
            status = "Good"
        else:
            color = COLORS['error']
            status = "Poor"
        
        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"**Latency:** {latency}ms\n**Status:** {status}",
            color=color
        )
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="serverinfo", description="Get information about the server")
    async def serverinfo(self, interaction: discord.Interaction):
        """Get server information"""
        guild = interaction.guild
        
        # Count members by status
        online = len([m for m in guild.members if m.status == discord.Status.online])
        idle = len([m for m in guild.members if m.status == discord.Status.idle])
        dnd = len([m for m in guild.members if m.status == discord.Status.dnd])
        offline = len([m for m in guild.members if m.status == discord.Status.offline])
        
        # Count channels
        text_channels = len([c for c in guild.channels if isinstance(c, discord.TextChannel)])
        voice_channels = len([c for c in guild.channels if isinstance(c, discord.VoiceChannel)])
        categories = len(guild.categories)
        
        embed = discord.Embed(
            title=f"📊 {guild.name} Server Information",
            color=COLORS['info']
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        embed.add_field(
            name="👥 Members",
            value=f"**Total:** {guild.member_count}\n🟢 Online: {online}\n🟡 Idle: {idle}\n🔴 DND: {dnd}\n⚫ Offline: {offline}",
            inline=True
        )
        
        embed.add_field(
            name="📺 Channels",
            value=f"**Total:** {len(guild.channels)}\n💬 Text: {text_channels}\n🔊 Voice: {voice_channels}\n📁 Categories: {categories}",
            inline=True
        )
        
        embed.add_field(
            name="🎭 Roles",
            value=f"**Total:** {len(guild.roles)}",
            inline=True
        )
        
        embed.add_field(
            name="👑 Owner",
            value=guild.owner.mention if guild.owner else "Unknown",
            inline=True
        )
        
        embed.add_field(
            name="📅 Created",
            value=guild.created_at.strftime("%B %d, %Y"),
            inline=True
        )
        
        embed.add_field(
            name="🔒 Verification",
            value=str(guild.verification_level).title(),
            inline=True
        )
        
        if guild.description:
            embed.add_field(
                name="📝 Description",
                value=guild.description,
                inline=False
            )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="userinfo", description="Get information about a user")
    @app_commands.describe(user="The user to get information about")
    async def userinfo(self, interaction: discord.Interaction, user: discord.Member = None):
        """Get user information"""
        if user is None:
            user = interaction.user
        
        embed = discord.Embed(
            title=f"👤 {user.display_name} User Information",
            color=user.color if user.color != discord.Color.default() else COLORS['info']
        )
        
        embed.set_thumbnail(url=user.display_avatar.url)
        
        embed.add_field(
            name="📛 Username",
            value=f"{user.name}#{user.discriminator}",
            inline=True
        )
        
        embed.add_field(
            name="🆔 User ID",
            value=user.id,
            inline=True
        )
        
        embed.add_field(
            name="📅 Account Created",
            value=user.created_at.strftime("%B %d, %Y"),
            inline=True
        )
        
        embed.add_field(
            name="📥 Joined Server",
            value=user.joined_at.strftime("%B %d, %Y") if user.joined_at else "Unknown",
            inline=True
        )
        
        embed.add_field(
            name="📱 Status",
            value=str(user.status).title(),
            inline=True
        )
        
        embed.add_field(
            name="🎮 Activity",
            value=user.activity.name if user.activity else "None",
            inline=True
        )
        
        # Get user's highest role
        if user.top_role.name != "@everyone":
            embed.add_field(
                name="🎭 Highest Role",
                value=user.top_role.mention,
                inline=True
            )
        
        # Count user's roles (excluding @everyone)
        roles = [role for role in user.roles if role.name != "@everyone"]
        if roles:
            embed.add_field(
                name="🎭 Roles",
                value=f"{len(roles)} roles",
                inline=True
            )
        
        # User permissions
        key_perms = []
        if user.guild_permissions.administrator:
            key_perms.append("Administrator")
        elif user.guild_permissions.manage_guild:
            key_perms.append("Manage Server")
        elif user.guild_permissions.manage_channels:
            key_perms.append("Manage Channels")
        elif user.guild_permissions.manage_messages:
            key_perms.append("Manage Messages")
        
        if key_perms:
            embed.add_field(
                name="🔑 Key Permissions",
                value=", ".join(key_perms),
                inline=False
            )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="avatar", description="Get a user's avatar")
    @app_commands.describe(user="The user to get the avatar of")
    async def avatar(self, interaction: discord.Interaction, user: discord.Member = None):
        """Get user's avatar"""
        if user is None:
            user = interaction.user
        
        embed = discord.Embed(
            title=f"🖼️ {user.display_name}'s Avatar",
            color=COLORS['info']
        )
        
        embed.set_image(url=user.display_avatar.url)
        embed.add_field(
            name="Direct Link",
            value=f"[Click here]({user.display_avatar.url})",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="botinfo", description="Get information about the bot")
    async def botinfo(self, interaction: discord.Interaction):
        """Get bot information"""
        embed = discord.Embed(
            title="🤖 Bot Information",
            color=COLORS['novarix']
        )
        
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        
        embed.add_field(
            name="📛 Bot Name",
            value=self.bot.user.name,
            inline=True
        )
        
        embed.add_field(
            name="🆔 Bot ID",
            value=self.bot.user.id,
            inline=True
        )
        
        embed.add_field(
            name="🌐 Servers",
            value=len(self.bot.guilds),
            inline=True
        )
        
        embed.add_field(
            name="👥 Users",
            value=len(self.bot.users),
            inline=True
        )
        
        embed.add_field(
            name="🐍 Python Version",
            value=platform.python_version(),
            inline=True
        )
        
        embed.add_field(
            name="📚 Discord.py Version",
            value=discord.__version__,
            inline=True
        )
        
        embed.add_field(
            name="⏰ Uptime",
            value="Since last restart",
            inline=True
        )
        
        embed.add_field(
            name="🏓 Ping",
            value=f"{round(self.bot.latency * 1000)}ms",
            inline=True
        )
        
        embed.add_field(
            name="💻 Platform",
            value=platform.system(),
            inline=True
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="roleinfo", description="Get information about a role")
    @app_commands.describe(role="The role to get information about")
    async def roleinfo(self, interaction: discord.Interaction, role: discord.Role):
        """Get role information"""
        embed = discord.Embed(
            title=f"🎭 {role.name} Role Information",
            color=role.color if role.color != discord.Color.default() else COLORS['info']
        )
        
        embed.add_field(
            name="📛 Name",
            value=role.name,
            inline=True
        )
        
        embed.add_field(
            name="🆔 Role ID",
            value=role.id,
            inline=True
        )
        
        embed.add_field(
            name="👥 Members",
            value=len(role.members),
            inline=True
        )
        
        embed.add_field(
            name="📅 Created",
            value=role.created_at.strftime("%B %d, %Y"),
            inline=True
        )
        
        embed.add_field(
            name="🎨 Color",
            value=str(role.color),
            inline=True
        )
        
        embed.add_field(
            name="📍 Position",
            value=f"{role.position}/{len(interaction.guild.roles)}",
            inline=True
        )
        
        embed.add_field(
            name="🔒 Hoisted",
            value="Yes" if role.hoist else "No",
            inline=True
        )
        
        embed.add_field(
            name="🤖 Bot Role",
            value="Yes" if role.is_bot_managed() else "No",
            inline=True
        )
        
        embed.add_field(
            name="📌 Mentionable",
            value="Yes" if role.mentionable else "No",
            inline=True
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Utility(bot))
