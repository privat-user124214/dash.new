import discord
from discord.ext import commands
from discord import app_commands
import json
import datetime
from config import COLORS, FOOTER_TEXT, TICKET_CATEGORY_NAME, TICKET_LOG_CHANNEL

class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, emoji="🔒")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Close the ticket"""
        # Check if user has permission to close ticket
        if not (interaction.user.guild_permissions.manage_channels or 
                interaction.channel.name.endswith(str(interaction.user.id))):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to close this ticket.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Create confirmation view
        confirm_view = ConfirmCloseView()
        embed = discord.Embed(
            title="⚠️ Confirm Ticket Closure",
            description="Are you sure you want to close this ticket? This action cannot be undone.",
            color=COLORS['warning']
        )
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed, view=confirm_view, ephemeral=True)

class ConfirmCloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)
    
    @discord.ui.button(label="Yes, Close", style=discord.ButtonStyle.danger)
    async def confirm_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Confirm ticket closure"""
        try:
            # Load tickets data
            with open('data/tickets.json', 'r') as f:
                tickets = json.load(f)
            
            # Update ticket status
            channel_id = str(interaction.channel.id)
            if channel_id in tickets:
                tickets[channel_id]['status'] = 'closed'
                tickets[channel_id]['closed_at'] = datetime.datetime.now().isoformat()
                tickets[channel_id]['closed_by'] = interaction.user.id
                
                with open('data/tickets.json', 'w') as f:
                    json.dump(tickets, f, indent=2)
            
            # Send closure message
            embed = discord.Embed(
                title="🔒 Ticket Closed",
                description=f"This ticket has been closed by {interaction.user.mention}.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
            
            # Delete channel after 5 seconds
            await interaction.channel.delete(reason=f"Ticket closed by {interaction.user}")
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description="Failed to close the ticket. Please try again.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Cancel ticket closure"""
        embed = discord.Embed(
            title="✅ Cancelled",
            description="Ticket closure has been cancelled.",
            color=COLORS['success']
        )
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class CreateTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Create Ticket", style=discord.ButtonStyle.primary, emoji="🎫")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Create a new ticket"""
        # Check if user already has an open ticket
        with open('data/tickets.json', 'r') as f:
            tickets = json.load(f)
        
        user_has_ticket = False
        for ticket_id, ticket_data in tickets.items():
            if (ticket_data['user_id'] == interaction.user.id and 
                ticket_data['guild_id'] == interaction.guild.id and 
                ticket_data['status'] == 'open'):
                user_has_ticket = True
                break
        
        if user_has_ticket:
            embed = discord.Embed(
                title="❌ Ticket Already Exists",
                description="You already have an open ticket. Please use your existing ticket or close it first.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Get or create ticket category
        category = discord.utils.get(interaction.guild.categories, name=TICKET_CATEGORY_NAME)
        if not category:
            try:
                category = await interaction.guild.create_category(TICKET_CATEGORY_NAME)
            except discord.Forbidden:
                embed = discord.Embed(
                    title="❌ Error",
                    description="I don't have permission to create channels.",
                    color=COLORS['error']
                )
                embed.set_footer(text=FOOTER_TEXT)
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
        
        # Create ticket channel
        channel_name = f"ticket-{interaction.user.name}-{interaction.user.id}"
        try:
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
                interaction.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
            }
            
            # Add moderator permissions
            for role in interaction.guild.roles:
                if role.permissions.manage_channels:
                    overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
            
            channel = await interaction.guild.create_text_channel(
                name=channel_name,
                category=category,
                overwrites=overwrites,
                topic=f"Support ticket for {interaction.user.display_name}"
            )
            
            # Save ticket data
            ticket_data = {
                'user_id': interaction.user.id,
                'guild_id': interaction.guild.id,
                'channel_id': channel.id,
                'created_at': datetime.datetime.now().isoformat(),
                'status': 'open'
            }
            
            tickets[str(channel.id)] = ticket_data
            with open('data/tickets.json', 'w') as f:
                json.dump(tickets, f, indent=2)
            
            # Send welcome message in ticket
            embed = discord.Embed(
                title="🎫 Support Ticket Created",
                description=f"Hello {interaction.user.mention}! Thank you for creating a support ticket.\n\nPlease describe your issue and a staff member will assist you shortly.",
                color=COLORS['success']
            )
            embed.add_field(name="Ticket ID", value=str(channel.id), inline=True)
            embed.add_field(name="Created", value=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), inline=True)
            embed.set_footer(text=FOOTER_TEXT)
            
            view = TicketView()
            await channel.send(embed=embed, view=view)
            
            # Respond to user
            embed = discord.Embed(
                title="✅ Ticket Created",
                description=f"Your ticket has been created: {channel.mention}",
                color=COLORS['success']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Error",
                description="I don't have permission to create channels.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)

class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="ticket-setup", description="Set up the ticket system in this channel")
    async def ticket_setup(self, interaction: discord.Interaction):
        """Set up the ticket system"""
        if not interaction.user.guild_permissions.manage_channels:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to set up the ticket system.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        embed = discord.Embed(
            title="🎫 Ticket System",
            description="Need help? Click the button below to create a support ticket.\n\nOur staff will assist you as soon as possible.",
            color=COLORS['novarix']
        )
        embed.add_field(
            name="How it works:",
            value="• Click 'Create Ticket'\n• A private channel will be created\n• Explain your issue\n• Wait for staff assistance\n• Close when resolved",
            inline=False
        )
        embed.set_footer(text=FOOTER_TEXT)
        
        view = CreateTicketView()
        await interaction.response.send_message(embed=embed, view=view)
    
    @app_commands.command(name="ticket-info", description="Get information about a ticket")
    @app_commands.describe(ticket_id="The ticket ID (channel ID)")
    async def ticket_info(self, interaction: discord.Interaction, ticket_id: str = None):
        """Get ticket information"""
        if not interaction.user.guild_permissions.manage_channels:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to view ticket information.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # If no ticket ID provided, use current channel
        if not ticket_id:
            ticket_id = str(interaction.channel.id)
        
        try:
            with open('data/tickets.json', 'r') as f:
                tickets = json.load(f)
        except:
            tickets = {}
        
        if ticket_id not in tickets:
            embed = discord.Embed(
                title="❌ Ticket Not Found",
                description="No ticket found with that ID.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        ticket = tickets[ticket_id]
        user = self.bot.get_user(ticket['user_id'])
        user_name = user.display_name if user else "Unknown User"
        
        embed = discord.Embed(
            title="🎫 Ticket Information",
            color=COLORS['info']
        )
        embed.add_field(name="Ticket ID", value=ticket_id, inline=True)
        embed.add_field(name="User", value=user_name, inline=True)
        embed.add_field(name="Status", value=ticket['status'].title(), inline=True)
        embed.add_field(name="Created", value=ticket['created_at'][:19], inline=True)
        
        if ticket['status'] == 'closed':
            closed_by = self.bot.get_user(ticket.get('closed_by', 0))
            closed_by_name = closed_by.display_name if closed_by else "Unknown"
            embed.add_field(name="Closed By", value=closed_by_name, inline=True)
            embed.add_field(name="Closed At", value=ticket.get('closed_at', 'Unknown')[:19], inline=True)
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="ticket-stats", description="View ticket statistics")
    async def ticket_stats(self, interaction: discord.Interaction):
        """View ticket statistics"""
        if not interaction.user.guild_permissions.manage_channels:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to view ticket statistics.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            with open('data/tickets.json', 'r') as f:
                tickets = json.load(f)
        except:
            tickets = {}
        
        guild_tickets = [t for t in tickets.values() if t['guild_id'] == interaction.guild.id]
        total_tickets = len(guild_tickets)
        open_tickets = len([t for t in guild_tickets if t['status'] == 'open'])
        closed_tickets = len([t for t in guild_tickets if t['status'] == 'closed'])
        
        embed = discord.Embed(
            title="📊 Ticket Statistics",
            color=COLORS['info']
        )
        embed.add_field(name="Total Tickets", value=total_tickets, inline=True)
        embed.add_field(name="Open Tickets", value=open_tickets, inline=True)
        embed.add_field(name="Closed Tickets", value=closed_tickets, inline=True)
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Tickets(bot))
