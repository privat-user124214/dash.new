import discord
from discord.ext import commands
from discord import app_commands
import json
import datetime
from typing import Optional
from config import COLORS, FOOTER_TEXT

class AdminConfigView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=300)
        self.bot = bot
    
    def load_admin_config(self, guild_id):
        try:
            with open('data/admin_config.json', 'r') as f:
                data = json.load(f)
            return data.get(str(guild_id), {})
        except:
            return {}
    
    def load_data(self, filename):
        try:
            filepath = 'data/' + filename
            with open(filepath, 'r') as f:
                return json.load(f)
        except:
            return {}
    
    @discord.ui.select(
        placeholder="Wähle eine Konfiguration...",
        options=[
            discord.SelectOption(label="🛡️ Anti-Raid Einstellungen", description="Raid-Schutz konfigurieren", value="antiraid"),
            discord.SelectOption(label="👥 Team Management", description="Team-Mitglieder verwalten", value="team"),
            discord.SelectOption(label="🎭 Rollensystem", description="Berechtigungen verwalten", value="roles"),
            discord.SelectOption(label="📊 Benutzer-Daten", description="Alle Benutzerdaten anzeigen", value="userdata"),
            discord.SelectOption(label="⚙️ Server Einstellungen", description="Allgemeine Einstellungen", value="settings")
        ]
    )
    async def select_config(self, interaction: discord.Interaction, select: discord.ui.Select):
        category = select.values[0]
        
        if category == "antiraid":
            await self.show_antiraid_config(interaction)
        elif category == "team":
            await self.show_team_management(interaction)
        elif category == "roles":
            await self.show_role_system(interaction)
        elif category == "userdata":
            await self.show_user_data(interaction)
        elif category == "settings":
            await self.show_server_settings(interaction)
    
    async def show_antiraid_config(self, interaction):
        config = self.load_admin_config(interaction.guild.id)
        
        embed = discord.Embed(
            title="🛡️ Anti-Raid Konfiguration",
            description="Schutz vor Discord-Raids konfigurieren",
            color=COLORS['error']
        )
        
        max_bans = config.get('max_bans_per_hour', 5)
        max_kicks = config.get('max_kicks_per_hour', 10)
        auto_lockdown = config.get('auto_lockdown', False)
        raid_alert = config.get('raid_alert', True)
        
        embed.add_field(
            name="Aktuelle Einstellungen",
            value=f"**Max. Bans pro Stunde:** {max_bans}\n"
                  f"**Max. Kicks pro Stunde:** {max_kicks}\n"
                  f"**Auto-Lockdown:** {'✅' if auto_lockdown else '❌'}\n"
                  f"**Raid-Alarm:** {'✅' if raid_alert else '❌'}",
            inline=False
        )
        
        embed.add_field(
            name="Befehle zur Konfiguration",
            value="`/admin-config set-ban-limit <anzahl>`\n"
                  "`/admin-config set-kick-limit <anzahl>`\n"
                  "`/admin-config toggle-lockdown`\n"
                  "`/admin-config toggle-raid-alert`",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def show_team_management(self, interaction):
        config = self.load_admin_config(interaction.guild.id)
        team = config.get('team_members', {})
        
        embed = discord.Embed(
            title="👥 Team Management",
            description="Team-Mitglieder und ihre Berechtigungen verwalten",
            color=COLORS['info']
        )
        
        owner = config.get('owner_id')
        co_owner = config.get('co_owner_id')
        
        if owner:
            owner_user = self.bot.get_user(owner)
            embed.add_field(
                name="👑 Inhaber",
                value=owner_user.mention if owner_user else f"<@{owner}>",
                inline=True
            )
        
        if co_owner:
            co_owner_user = self.bot.get_user(co_owner)
            embed.add_field(
                name="👑 2. Inhaber",
                value=co_owner_user.mention if co_owner_user else f"<@{co_owner}>",
                inline=True
            )
        
        if team:
            team_list = []
            for user_id, role in team.items():
                user = self.bot.get_user(int(user_id))
                team_list.append(f"{user.mention if user else f'<@{user_id}>'} - {role}")
            
            embed.add_field(
                name="Team-Mitglieder",
                value="\n".join(team_list) if team_list else "Keine Team-Mitglieder",
                inline=False
            )
        
        embed.add_field(
            name="Team-Befehle",
            value="`/admin-team add <user> <rolle>`\n"
                  "`/admin-team remove <user>`\n"
                  "`/admin-team set-co-owner <user>`\n"
                  "`/admin-team list`",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def show_role_system(self, interaction):
        embed = discord.Embed(
            title="🎭 Rollensystem",
            description="Berechtigungssystem für Team-Mitglieder",
            color=COLORS['warning']
        )
        
        roles_info = {
            "admin": "Vollzugriff auf alle Funktionen",
            "moderator": "Moderation + Ticket-System",
            "supporter": "Nur Ticket-System und Basis-Moderation",
            "viewer": "Nur Daten einsehen, keine Aktionen"
        }
        
        for role, desc in roles_info.items():
            embed.add_field(
                name=f"**{role.upper()}**",
                value=desc,
                inline=False
            )
        
        embed.add_field(
            name="Berechtigungen verwalten",
            value="`/admin-permissions set <user> <rolle>`\n"
                  "`/admin-permissions list`\n"
                  "`/admin-permissions check <user>`",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def show_user_data(self, interaction):
        warnings = self.load_data('warnings.json')
        muted_users = self.load_data('muted_users.json')
        tickets = self.load_data('tickets.json')
        config = self.load_admin_config(interaction.guild.id)
        
        guild_id = str(interaction.guild.id)
        
        embed = discord.Embed(
            title="📊 Server-Datenübersicht",
            description="Vollständige Übersicht aller Benutzerdaten",
            color=COLORS['info']
        )
        
        total_warnings = len(warnings.get(guild_id, {}))
        total_muted = len([u for u in muted_users.values() if u.get('guild_id') == interaction.guild.id])
        total_tickets = len([t for t in tickets.values() if t.get('guild_id') == interaction.guild.id])
        
        embed.add_field(
            name="📈 Statistiken",
            value=f"**Verwarnungen:** {total_warnings} Benutzer\n"
                  f"**Stummgeschaltet:** {total_muted} Benutzer\n"
                  f"**Tickets:** {total_tickets} erstellt",
            inline=True
        )
        
        today = datetime.datetime.now().date()
        actions_today = config.get('daily_actions', {}).get(str(today), {})
        
        embed.add_field(
            name="📅 Heute",
            value=f"**Bans:** {actions_today.get('bans', 0)}\n"
                  f"**Kicks:** {actions_today.get('kicks', 0)}\n"
                  f"**Mutes:** {actions_today.get('mutes', 0)}",
            inline=True
        )
        
        embed.add_field(
            name="Daten-Befehle",
            value="`/admin-data export` - Alle Daten exportieren\n"
                  "`/admin-data user <user>` - Benutzerdaten anzeigen\n"
                  "`/admin-data stats` - Detaillierte Statistiken",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def show_server_settings(self, interaction):
        config = self.load_admin_config(interaction.guild.id)
        
        embed = discord.Embed(
            title="⚙️ Server Einstellungen",
            description="Allgemeine Bot-Konfiguration für diesen Server",
            color=COLORS['success']
        )
        
        log_channel = config.get('log_channel')
        log_text = f"<#{log_channel}>" if log_channel else 'Nicht gesetzt'
        welcome_status = '✅' if config.get('welcome_message', False) else '❌'
        automod_status = '✅' if config.get('auto_moderation', False) else '❌'
        backup_status = '✅' if config.get('backup_enabled', False) else '❌'
        
        embed.add_field(
            name="Aktuelle Einstellungen",
            value=f"**Log-Kanal:** {log_text}\n"
                  f"**Willkommens-Nachricht:** {welcome_status}\n"
                  f"**Auto-Mod:** {automod_status}\n"
                  f"**Backup-System:** {backup_status}",
            inline=False
        )
        
        embed.add_field(
            name="Konfigurationsbefehle",
            value="`/admin-settings set-log-channel <kanal>`\n"
                  "`/admin-settings toggle-welcome`\n"
                  "`/admin-settings toggle-automod`\n"
                  "`/admin-settings backup`",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.edit_message(embed=embed, view=self)

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    def load_admin_config(self, guild_id):
        try:
            with open('data/admin_config.json', 'r') as f:
                data = json.load(f)
            return data.get(str(guild_id), {})
        except:
            return {}
    
    def save_admin_config(self, guild_id, config):
        try:
            with open('data/admin_config.json', 'r') as f:
                data = json.load(f)
        except:
            data = {}
        
        data[str(guild_id)] = config
        
        with open('data/admin_config.json', 'w') as f:
            json.dump(data, f, indent=2)
    
    def has_admin_permission(self, user_id, guild_id, required_level="viewer"):
        config = self.load_admin_config(guild_id)
        
        if user_id == config.get('owner_id') or user_id == config.get('co_owner_id'):
            return True
        
        team = config.get('team_members', {})
        user_role = team.get(str(user_id))
        
        if not user_role:
            return False
        
        levels = {"viewer": 0, "supporter": 1, "moderator": 2, "admin": 3}
        
        return levels.get(user_role, 0) >= levels.get(required_level, 0)
    
    def track_action(self, guild_id, action_type):
        config = self.load_admin_config(guild_id)
        today = str(datetime.datetime.now().date())
        
        if 'daily_actions' not in config:
            config['daily_actions'] = {}
        
        if today not in config['daily_actions']:
            config['daily_actions'][today] = {}
        
        config['daily_actions'][today][action_type] = config['daily_actions'][today].get(action_type, 0) + 1
        
        self.save_admin_config(guild_id, config)
        
        return self.check_action_limits(guild_id, action_type, config['daily_actions'][today][action_type])
    
    def check_action_limits(self, guild_id, action_type, current_count):
        config = self.load_admin_config(guild_id)
        
        limits = {
            'bans': config.get('max_bans_per_hour', 5),
            'kicks': config.get('max_kicks_per_hour', 10)
        }
        
        limit = limits.get(action_type)
        if limit and current_count >= limit:
            return False
        
        return True
    
    @app_commands.command(name="admin-panel", description="Team-Management Panel öffnen")
    async def admin_panel(self, interaction: discord.Interaction):
        if not self.has_admin_permission(interaction.user.id, interaction.guild.id, "viewer"):
            embed = discord.Embed(
                title="❌ Zugriff verweigert",
                description="Du hast keine Berechtigung für das Admin-Panel.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        embed = discord.Embed(
            title="🛠️ Admin-Panel",
            description="Willkommen im Team-Management System",
            color=COLORS['novarix']
        )
        
        embed.add_field(
            name="🛡️ Anti-Raid System",
            value="Schutz vor Discord-Raids und Massenaktionen",
            inline=True
        )
        
        embed.add_field(
            name="👥 Team Management",
            value="Team-Mitglieder und Berechtigungen verwalten",
            inline=True
        )
        
        embed.add_field(
            name="📊 Datenübersicht",
            value="Vollständige Benutzerdaten und Statistiken",
            inline=True
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        
        view = AdminConfigView(self.bot)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    @app_commands.command(name="admin-setup", description="Ersteinrichtung des Admin-Systems")
    @app_commands.describe(co_owner="Optionaler 2. Inhaber")
    async def admin_setup(self, interaction: discord.Interaction, co_owner: Optional[discord.Member] = None):
        if not interaction.user.guild_permissions.administrator:
            embed = discord.Embed(
                title="❌ Zugriff verweigert",
                description="Nur Administratoren können das Admin-System einrichten.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        config = self.load_admin_config(interaction.guild.id)
        config['owner_id'] = interaction.user.id
        
        if co_owner:
            config['co_owner_id'] = co_owner.id
        
        config.setdefault('max_bans_per_hour', 5)
        config.setdefault('max_kicks_per_hour', 10)
        config.setdefault('auto_lockdown', False)
        config.setdefault('raid_alert', True)
        config.setdefault('team_members', {})
        
        self.save_admin_config(interaction.guild.id, config)
        
        embed = discord.Embed(
            title="✅ Admin-System eingerichtet",
            description="Das Team-Management System wurde erfolgreich konfiguriert.",
            color=COLORS['success']
        )
        
        embed.add_field(
            name="👑 Inhaber",
            value=interaction.user.mention,
            inline=True
        )
        
        if co_owner:
            embed.add_field(
                name="👑 2. Inhaber",
                value=co_owner.mention,
                inline=True
            )
        
        embed.add_field(
            name="Nächste Schritte",
            value="Verwende `/admin-panel` um das System zu verwalten",
            inline=False
        )
        
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="admin-team", description="Team-Mitglied hinzufügen/entfernen")
    @app_commands.describe(
        action="Aktion (add/remove/list)",
        user="Benutzer",
        role="Rolle (admin/moderator/supporter/viewer)"
    )
    async def admin_team(self, interaction: discord.Interaction, action: str, user: Optional[discord.Member] = None, role: Optional[str] = None):
        if not self.has_admin_permission(interaction.user.id, interaction.guild.id, "admin"):
            embed = discord.Embed(
                title="❌ Zugriff verweigert",
                description="Du benötigst Admin-Berechtigung für diese Aktion.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        config = self.load_admin_config(interaction.guild.id)
        
        if action == "add":
            if not user or not role:
                embed = discord.Embed(
                    title="❌ Fehler",
                    description="Benutzer und Rolle sind erforderlich.",
                    color=COLORS['error']
                )
                embed.set_footer(text=FOOTER_TEXT)
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            valid_roles = ["admin", "moderator", "supporter", "viewer"]
            if role not in valid_roles:
                embed = discord.Embed(
                    title="❌ Ungültige Rolle",
                    description=f"Gültige Rollen: {', '.join(valid_roles)}",
                    color=COLORS['error']
                )
                embed.set_footer(text=FOOTER_TEXT)
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            if 'team_members' not in config:
                config['team_members'] = {}
            
            config['team_members'][str(user.id)] = role
            self.save_admin_config(interaction.guild.id, config)
            
            embed = discord.Embed(
                title="✅ Team-Mitglied hinzugefügt",
                description=f"{user.mention} wurde als **{role}** hinzugefügt.",
                color=COLORS['success']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
        
        elif action == "remove":
            if not user:
                embed = discord.Embed(
                    title="❌ Fehler",
                    description="Benutzer ist erforderlich.",
                    color=COLORS['error']
                )
                embed.set_footer(text=FOOTER_TEXT)
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            if str(user.id) in config.get('team_members', {}):
                del config['team_members'][str(user.id)]
                self.save_admin_config(interaction.guild.id, config)
                
                embed = discord.Embed(
                    title="✅ Team-Mitglied entfernt",
                    description=f"{user.mention} wurde aus dem Team entfernt.",
                    color=COLORS['success']
                )
                embed.set_footer(text=FOOTER_TEXT)
                await interaction.response.send_message(embed=embed)
            else:
                embed = discord.Embed(
                    title="❌ Nicht gefunden",
                    description="Benutzer ist kein Team-Mitglied.",
                    color=COLORS['error']
                )
                embed.set_footer(text=FOOTER_TEXT)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        
        elif action == "list":
            team = config.get('team_members', {})
            
            embed = discord.Embed(
                title="👥 Team-Übersicht",
                color=COLORS['info']
            )
            
            if team:
                team_list = []
                for user_id, user_role in team.items():
                    user_obj = self.bot.get_user(int(user_id))
                    team_list.append(f"{user_obj.mention if user_obj else f'<@{user_id}>'} - **{user_role}**")
                
                embed.description = "\n".join(team_list)
            else:
                embed.description = "Keine Team-Mitglieder vorhanden."
            
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="admin-data", description="Benutzerdaten verwalten und exportieren")
    @app_commands.describe(
        action="Aktion (user/export/stats)",
        user="Benutzer für detaillierte Daten"
    )
    async def admin_data(self, interaction: discord.Interaction, action: str, user: Optional[discord.Member] = None):
        if not self.has_admin_permission(interaction.user.id, interaction.guild.id, "viewer"):
            embed = discord.Embed(
                title="❌ Zugriff verweigert",
                description="Du hast keine Berechtigung für diese Aktion.",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if action == "user" and user:
            embed = discord.Embed(
                title=f"📊 Daten für {user.display_name}",
                color=COLORS['info']
            )
            
            warnings = self.load_data('warnings.json')
            muted_users = self.load_data('muted_users.json')
            tickets = self.load_data('tickets.json')
            
            guild_id = str(interaction.guild.id)
            user_id = str(user.id)
            
            user_warnings = warnings.get(guild_id, {}).get(user_id, [])
            embed.add_field(
                name="⚠️ Verwarnungen",
                value=f"{len(user_warnings)} insgesamt",
                inline=True
            )
            
            is_muted = user_id in muted_users
            embed.add_field(
                name="🔇 Stummgeschaltet",
                value="Ja" if is_muted else "Nein",
                inline=True
            )
            
            user_tickets = [t for t in tickets.values() if t.get('user_id') == user.id]
            embed.add_field(
                name="🎫 Tickets",
                value=f"{len(user_tickets)} erstellt",
                inline=True
            )
            
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed)
        
        elif action == "export":
            if not self.has_admin_permission(interaction.user.id, interaction.guild.id, "admin"):
                embed = discord.Embed(
                    title="❌ Zugriff verweigert",
                    description="Du benötigst Admin-Berechtigung zum Exportieren.",
                    color=COLORS['error']
                )
                embed.set_footer(text=FOOTER_TEXT)
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            embed = discord.Embed(
                title="📤 Daten exportiert",
                description="Alle Server-Daten wurden erfolgreich zusammengestellt.",
                color=COLORS['success']
            )
            embed.add_field(
                name="Verfügbare Daten",
                value="• Verwarnungen\n• Stummgeschaltete Benutzer\n• Ticket-Verlauf\n• Admin-Konfiguration",
                inline=False
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    def load_data(self, filename):
        try:
            filepath = 'data/' + filename
            with open(filepath, 'r') as f:
                return json.load(f)
        except:
            return {}

async def setup(bot):
    await bot.add_cog(Admin(bot))