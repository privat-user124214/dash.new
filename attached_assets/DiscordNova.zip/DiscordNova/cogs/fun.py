import discord
from discord.ext import commands
from discord import app_commands
import random
import datetime
from config import COLORS, FOOTER_TEXT

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="8ball", description="Ask the magic 8-ball a question")
    @app_commands.describe(question="Your question for the 8-ball")
    async def eightball(self, interaction: discord.Interaction, question: str):
        """Magic 8-ball command"""
        responses = [
            "🎱 It is certain",
            "🎱 It is decidedly so",
            "🎱 Without a doubt",
            "🎱 Yes definitely",
            "🎱 You may rely on it",
            "🎱 As I see it, yes",
            "🎱 Most likely",
            "🎱 Outlook good",
            "🎱 Yes",
            "🎱 Signs point to yes",
            "🎱 Reply hazy, try again",
            "🎱 Ask again later",
            "🎱 Better not tell you now",
            "🎱 Cannot predict now",
            "🎱 Concentrate and ask again",
            "🎱 Don't count on it",
            "🎱 My reply is no",
            "🎱 My sources say no",
            "🎱 Outlook not so good",
            "🎱 Very doubtful"
        ]
        
        response = random.choice(responses)
        
        embed = discord.Embed(
            title="🎱 Magic 8-Ball",
            color=COLORS['info']
        )
        embed.add_field(name="Question", value=question, inline=False)
        embed.add_field(name="Answer", value=response, inline=False)
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="roll", description="Roll a dice")
    @app_commands.describe(sides="Number of sides on the dice (default: 6)")
    async def roll(self, interaction: discord.Interaction, sides: int = 6):
        """Roll a dice"""
        if sides < 2:
            embed = discord.Embed(
                title="❌ Invalid Dice",
                description="Dice must have at least 2 sides!",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if sides > 1000:
            embed = discord.Embed(
                title="❌ Too Many Sides",
                description="Maximum of 1000 sides allowed!",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        result = random.randint(1, sides)
        
        embed = discord.Embed(
            title="🎲 Dice Roll",
            description=f"You rolled a **{result}** on a {sides}-sided dice!",
            color=COLORS['success']
        )
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="coinflip", description="Flip a coin")
    async def coinflip(self, interaction: discord.Interaction):
        """Flip a coin"""
        result = random.choice(["Heads", "Tails"])
        emoji = "👑" if result == "Heads" else "⚫"
        
        embed = discord.Embed(
            title=f"{emoji} Coin Flip",
            description=f"The coin landed on **{result}**!",
            color=COLORS['info']
        )
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="choose", description="Choose randomly from a list of options")
    @app_commands.describe(options="Options separated by commas")
    async def choose(self, interaction: discord.Interaction, options: str):
        """Choose from options"""
        choices = [choice.strip() for choice in options.split(',')]
        
        if len(choices) < 2:
            embed = discord.Embed(
                title="❌ Not Enough Options",
                description="Please provide at least 2 options separated by commas!",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        choice = random.choice(choices)
        
        embed = discord.Embed(
            title="🤔 Random Choice",
            description=f"I choose: **{choice}**",
            color=COLORS['success']
        )
        embed.add_field(
            name="Options",
            value=", ".join(choices),
            inline=False
        )
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="joke", description="Get a random joke")
    async def joke(self, interaction: discord.Interaction):
        """Random joke command"""
        jokes = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "Why did the scarecrow win an award? He was outstanding in his field!",
            "Why don't eggs tell jokes? They'd crack each other up!",
            "What do you call a fake noodle? An impasta!",
            "Why did the math book look so sad? Because it had too many problems!",
            "What do you call a bear with no teeth? A gummy bear!",
            "Why don't programmers like nature? It has too many bugs!",
            "What's the best thing about Switzerland? I don't know, but the flag is a big plus!",
            "Why did the coffee file a police report? It got mugged!",
            "What do you call a dinosaur that crashes his car? Tyrannosaurus Wrecks!"
        ]
        
        joke = random.choice(jokes)
        
        embed = discord.Embed(
            title="😂 Random Joke",
            description=joke,
            color=COLORS['warning']
        )
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="compliment", description="Get a random compliment")
    @app_commands.describe(user="User to compliment (optional)")
    async def compliment(self, interaction: discord.Interaction, user: discord.Member = None):
        """Give a compliment"""
        if user is None:
            user = interaction.user
        
        compliments = [
            "You're an amazing person!",
            "You have a great sense of humor!",
            "You're incredibly talented!",
            "You light up the room!",
            "You're a great friend!",
            "You're very creative!",
            "You have excellent taste!",
            "You're really smart!",
            "You're very kind!",
            "You make everyone smile!"
        ]
        
        compliment = random.choice(compliments)
        
        embed = discord.Embed(
            title="💖 Compliment",
            description=f"{user.mention}, {compliment}",
            color=COLORS['success']
        )
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="meme", description="Get a random meme quote")
    async def meme(self, interaction: discord.Interaction):
        """Random meme quote"""
        memes = [
            "This is fine. 🔥",
            "I have achieved comedy 📈",
            "It's Wednesday my dudes! 🐸",
            "Stonks 📈",
            "Such wow, very bot 🐕",
            "404: Humor not found 🤖",
            "Press F to pay respects 😔",
            "That's what she said 😏",
            "Big brain time 🧠",
            "No u 🔄"
        ]
        
        meme = random.choice(memes)
        
        embed = discord.Embed(
            title="😎 Meme",
            description=meme,
            color=COLORS['novarix']
        )
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="rps", description="Play Rock Paper Scissors with the bot")
    @app_commands.describe(choice="Your choice: rock, paper, or scissors")
    async def rps(self, interaction: discord.Interaction, choice: str):
        """Rock Paper Scissors game"""
        choice = choice.lower()
        valid_choices = ['rock', 'paper', 'scissors']
        
        if choice not in valid_choices:
            embed = discord.Embed(
                title="❌ Invalid Choice",
                description="Please choose rock, paper, or scissors!",
                color=COLORS['error']
            )
            embed.set_footer(text=FOOTER_TEXT)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        bot_choice = random.choice(valid_choices)
        
        # Determine winner
        if choice == bot_choice:
            result = "It's a tie!"
            color = COLORS['warning']
        elif (choice == 'rock' and bot_choice == 'scissors') or \
             (choice == 'paper' and bot_choice == 'rock') or \
             (choice == 'scissors' and bot_choice == 'paper'):
            result = "You win!"
            color = COLORS['success']
        else:
            result = "I win!"
            color = COLORS['error']
        
        # Emojis for choices
        emoji_map = {'rock': '🪨', 'paper': '📄', 'scissors': '✂️'}
        
        embed = discord.Embed(
            title="🎮 Rock Paper Scissors",
            color=color
        )
        embed.add_field(name="Your Choice", value=f"{emoji_map[choice]} {choice.title()}", inline=True)
        embed.add_field(name="My Choice", value=f"{emoji_map[bot_choice]} {bot_choice.title()}", inline=True)
        embed.add_field(name="Result", value=result, inline=False)
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="quote", description="Get an inspirational quote")
    async def quote(self, interaction: discord.Interaction):
        """Random inspirational quote"""
        quotes = [
            "The only way to do great work is to love what you do. - Steve Jobs",
            "Innovation distinguishes between a leader and a follower. - Steve Jobs",
            "Life is what happens to you while you're busy making other plans. - John Lennon",
            "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
            "It is during our darkest moments that we must focus to see the light. - Aristotle",
            "The only impossible journey is the one you never begin. - Tony Robbins",
            "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
            "The way to get started is to quit talking and begin doing. - Walt Disney",
            "Don't let yesterday take up too much of today. - Will Rogers",
            "You learn more from failure than from success. Don't let it stop you. Failure builds character. - Unknown"
        ]
        
        quote = random.choice(quotes)
        
        embed = discord.Embed(
            title="💭 Inspirational Quote",
            description=quote,
            color=COLORS['info']
        )
        embed.set_footer(text=FOOTER_TEXT)
        
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Fun(bot))
