import discord
from discord.ext import commands
import asyncio
import logging
import os
import json
from config import BOT_TOKEN, COMMAND_PREFIX, INTENTS

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create data directory if it doesn't exist
os.makedirs('data', exist_ok=True)

# Initialize data files if they don't exist
data_files = ['data/warnings.json', 'data/tickets.json', 'data/muted_users.json']
for file_path in data_files:
    if not os.path.exists(file_path):
        with open(file_path, 'w') as f:
            json.dump({}, f)

class NovarixBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=COMMAND_PREFIX,
            intents=INTENTS,
            help_command=None  # We'll implement our own help system
        )
        
    async def setup_hook(self):
        """Load all cogs when the bot starts"""
        try:
            await self.load_extension('cogs.security')
            await self.load_extension('cogs.tickets')
            await self.load_extension('cogs.utility')
            await self.load_extension('cogs.fun')
            await self.load_extension('cogs.help')
            await self.load_extension('cogs.admin')
            logger.info("All cogs loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load cogs: {e}")
    
    async def on_ready(self):
        """Event triggered when bot is ready"""
        logger.info(f'{self.user} has connected to Discord!')
        logger.info(f'Bot is in {len(self.guilds)} guilds')
        
        # Sync slash commands
        try:
            synced = await self.tree.sync()
            logger.info(f"Synced {len(synced)} command(s)")
        except Exception as e:
            logger.error(f"Failed to sync commands: {e}")
    
    async def on_command_error(self, ctx, error):
        """Global error handler"""
        if isinstance(error, commands.CommandNotFound):
            return  # Ignore command not found errors
        
        embed = discord.Embed(
            title="❌ Error",
            description=f"An error occurred: {str(error)}",
            color=0xff0000
        )
        embed.set_footer(text="Powered by Novarix Studio")
        
        try:
            await ctx.send(embed=embed)
        except:
            pass  # Channel might be deleted or bot lacks permissions
        
        logger.error(f"Command error: {error}")

# Create bot instance
bot = NovarixBot()

async def main():
    """Main function to run the bot"""
    try:
        await bot.start(BOT_TOKEN)
    except discord.LoginFailure:
        logger.error("Invalid bot token provided")
    except Exception as e:
        logger.error(f"Failed to start bot: {e}")

if __name__ == "__main__":
    asyncio.run(main())
